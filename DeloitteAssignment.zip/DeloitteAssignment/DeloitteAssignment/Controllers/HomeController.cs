﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeloitteAssignment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace DeloitteAssignment.Controllers
{
    public class HomeController : Controller
    {
        private static readonly IList<EmployeeModel> _allEmployees;

        static HomeController()
        {
            _allEmployees = new List<EmployeeModel>
            {
                new EmployeeModel
                {
                    Id = 1,
                    ImageUrl = "2.png",
                    WorkTitle = "Programmer",
                    Name = "Gilad Mordekovich"
                },
                new EmployeeModel
                {
                    Id = 2,
                    ImageUrl = "4.png",
                    WorkTitle = "Programmer",
                    Name = "Yonatan Mordekovich"
                },
                new EmployeeModel
                {
                    Id = 3,
                    ImageUrl = "1.png",
                    WorkTitle = "Product Manager",
                    Name = "Yael Mordekovich"
                },
                new EmployeeModel
                {
                    Id = 4,
                    ImageUrl = "3.png",
                    WorkTitle = "Manager",
                    Name = "Rivka Mordekovich"
                },
                new EmployeeModel
                {
                    Id = 5,
                    ImageUrl = "2.png",
                    WorkTitle = "Product Manager",
                    Name = "Idan Dori"
                },
                new EmployeeModel
                {
                    Id = 6,
                    ImageUrl = "4.png",
                    WorkTitle = "Designer",
                    Name = "Elyakim Sharabi"
                },
                new EmployeeModel
                {
                    Id = 7,
                    ImageUrl = "4.png",
                    WorkTitle = "Designer",
                    Name = "Gilad Rachamim"
                },
                new EmployeeModel
                {
                    Id = 8,
                    ImageUrl = "1.png",
                    WorkTitle = "CEO",
                    Name = "Lital Yaish"
                },
                new EmployeeModel
                {
                    Id = 9,
                    ImageUrl = "3.png",
                    WorkTitle = "Team Leader",
                    Name = "Simcha Yaish"
                },
                new EmployeeModel
                {
                    Id = 10,
                    ImageUrl = "2.png",
                    WorkTitle = "Programmer",
                    Name = "Mor Dekovich"
                },
                new EmployeeModel
                {
                    Id = 11,
                    ImageUrl = "4.png",
                    WorkTitle = "Programmer",
                    Name = "Yoyo Yehuda"
                },
                                new EmployeeModel
                {
                    Id = 12,
                    ImageUrl = "1.png",
                    WorkTitle = "Secretary",
                    Name = "Zaava Akerman"
                },
                new EmployeeModel
                {
                    Id = 13,
                    ImageUrl = "3.png",
                    WorkTitle = "Team Leader",
                    Name = "Haim Mor"
                },
            };
        }
        public IActionResult Index()
        {
            return View();
        }

        [Route("employees")]
        //[HttpPost]
        public ActionResult Employees(string value)
        {
            List<EmployeeModel> _filteredEmployees = new List<EmployeeModel>{};
            if (value != null && value != "")
            {
                string seffixValue = value.ToLower().Remove(value.Length - 1);
                _filteredEmployees = _allEmployees.Where(employee => 
                                                         employee.WorkTitle.ToLower().Contains(seffixValue) 
                                                      || employee.Name.ToLower().Contains(seffixValue)).ToList();
            }
            else
            {
                _filteredEmployees = (List<EmployeeModel>)_allEmployees;
            }

            return Json(_filteredEmployees);
        }

    }
}
