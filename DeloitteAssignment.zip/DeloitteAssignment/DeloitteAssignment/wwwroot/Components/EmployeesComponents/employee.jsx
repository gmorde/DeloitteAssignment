﻿
class Employee extends React.Component {
    constructor(props) {
        super(props);
        this.highlightText = this.highlightText.bind(this);
    }
    highlightText(text, highlight) {
        if (typeof (highlight) != 'undefined' && highlight != undefined)
        {
            const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
            return (
                <span>
                    {parts.map((part, index) =>
                        <span key={index}
                            style={part.toLowerCase() === highlight.toLowerCase()
                                ? { fontWeight: 'bold', backgroundColor: 'rgba(255, 255, 61, 0.8)' }
                                : {}}>
                            {part}
                        </span>)}
                </span>
            );
        }
        else
        {
            return (
                <span>{text}</span>
            );
        }
    }
    render() {
        return (
            <div className="employee">
                <img src={'../Assets/Images/' + this.props.imageUrl} />
                <div className="details">
                    <span className="employee-name">
                        {this.highlightText(this.props.name, this.props.autocompleteValue)}
                    </span>
                    <span className="employee-work-title">
                        {this.highlightText(this.props.workTitle, this.props.autocompleteValue)}
                    </span>
                </div>
            </div>
        );
    }
}
export default Employee;