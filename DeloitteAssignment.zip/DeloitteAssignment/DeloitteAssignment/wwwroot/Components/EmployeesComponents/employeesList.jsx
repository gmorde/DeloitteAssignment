﻿import Employee from "./employee.jsx";

class EmployeesList extends React.Component {
    render() {
        const employeeDetails = this.props.data.map(employee => (
            <Employee
                key={employee.id}
                name={employee.name}
                workTitle={employee.workTitle}
                imageUrl={employee.imageUrl}
                autocompleteValue={this.props.autocompleteValue}>
            </Employee>
        ));
        return (
            <div className="employees-list-wrapper">
                <div className="employees-list">
                    {employeeDetails}
                </div>
            </div>
        );
    }
}
export default EmployeesList;
