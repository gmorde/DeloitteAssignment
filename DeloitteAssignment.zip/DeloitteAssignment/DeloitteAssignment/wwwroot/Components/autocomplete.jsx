﻿import EmployeesList from "./EmployeesComponents/employeesList.jsx";

class Autocomplete extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            autocompleteValue: ''
        };
        this.handleAutocompleteChange = this.handleAutocompleteChange.bind(this);
        this.handleAutocompleteBlur = this.handleAutocompleteBlur.bind(this);
        this.handleSubmitSearchResult = this.handleSubmitSearchResult.bind(this);

    }
    handleAutocompleteChange(event) {
        let autocompleteValue = event.target.value;
        this.setState({ autocompleteValue: autocompleteValue });
        if (autocompleteValue.length <= 1) {
            this.handleAutocompleteBlur();
        }
        if (autocompleteValue.length > 1)
        {
            this.props.onAutocompleteChange({ value: autocompleteValue })
        }
    }
    handleAutocompleteBlur() {
        this.props.autocompleteBlurEvent();
    }
    handleSubmitSearchResult() {
        this.props.submitSearch({ value: this.state.autocompleteValue });
    }
    render() {
        return (
            <div className="content-autocomplete-wrapper">
                <div className="the-autocomplete">
                    <input
                        type="text"
                        className="autocomplete-input"
                        placeholder="Search..."
                        value={this.state.autocompleteValue}
                        onChange={this.handleAutocompleteChange}
                        onFocus={this.handleAutocompleteChange}
                        onBlur={this.handleAutocompleteBlur}
                    />
                    <button
                        className="autocomplete-button"
                        onClick={this.handleSubmitSearchResult}>
                        <img src="../Assets/Images/search-icon.png" />
                    </button>
                </div>

                {this.props.appStatus == 'dropdown' ? (
                    <EmployeesList
                        data={this.props.data}
                        autocompleteValue={this.state.autocompleteValue} />
                ) : (<span></span>)}
            </div>
        )
    }
}
export default Autocomplete;