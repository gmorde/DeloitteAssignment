﻿
class HttpService extends React.Component  {
    constructor() {
        super();
        this.data = [];
        this.getEmployees = this.getEmployees.bind(this);
    }

    getEmployees(autocompleteValue, callback) {
        const http = new XMLHttpRequest();
        let params = "?Value=" + autocompleteValue.value + ".";

        http.open('get', "/employees" + params, true);
        http.onreadystatechange = () => {
            if (http.readyState == 4 && http.status == 200)
            {
                this.data = JSON.parse(http.response);
                callback(this.data);
            }
        };
        http.send(null);
    }

}
export default HttpService;
