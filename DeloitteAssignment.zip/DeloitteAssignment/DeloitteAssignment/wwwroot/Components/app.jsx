﻿import Autocomplete from "./autocomplete.jsx";
import EmployeesList from "./EmployeesComponents/employeesList.jsx";
import HttpService from "./service.jsx"
const httpService = new HttpService();

class EmployeesApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            status: 'dropdown',
            title: 'LOOKING FOR AN EMPLOYEE?',
            subtitle: 'Click on the search bar to learn our suggestions'
        };
        this.loadEmployeesFromServer = this.loadEmployeesFromServer.bind(this);
        this.emptyEmployeesList = this.emptyEmployeesList.bind(this);
        this.displayResults = this.displayResults.bind(this);
    }
    loadEmployeesFromServer(autocompleteValue) {
        if (this.state.status === 'result' || this.state.status === '')
        {
            this.changeStatusToDropDown();
        }
        let self = this;
        httpService.getEmployees(autocompleteValue, function (response) {
            self.setState({
                data: response
            })
        })
    }
    emptyEmployeesList() {
        this.setState({
            status: ''
        })
    }
    displayResults(autocompleteValue) {
        this.loadEmployeesFromServer(autocompleteValue);
        this.setState({
            title: 'SEARCH RESULTS',
            subtitle: '',
            status: 'result'
        })
    }
    changeStatusToDropDown() {
        this.setState({
            title: 'LOOKING FOR AN EMPLOYEE?',
            subtitle: 'Click on the search bar to learn our suggestions',
            status: 'dropdown'
        })
    }
    render() {
        return (
            <div className="employees-app">
                <div className="app-header">
                    <img src="../Assets/Images/deloitte-logo.png" />
                    <p>| GILAD MORDEKOVICH</p>
                </div>
                <div className="app-content">
                    <p className="content-title">{this.state.title}</p>
                    <p className="content-subtitle">{this.state.subtitle}</p>

                    <Autocomplete
                        data={this.state.data}
                        onSearchSubmit={this.submitSearchResult}
                        onAutocompleteChange={this.loadEmployeesFromServer}
                        autocompleteBlurEvent={this.emptyEmployeesList}
                        submitSearch={this.displayResults}
                        appStatus={this.state.status} />

                    {this.state.status == 'result' ? (
                        <div className="search-results-wrapper">
                            <EmployeesList data={this.state.data}/>
                        </div>
                    ) : (<span></span>)}

                </div>
            </div>
        );
    }
}

ReactDOM.render(
    <EmployeesApp />,
    document.getElementById('content'),
);

